public interface PlaybackInterface {
    void play();
    void pause();
    void stop();
}
