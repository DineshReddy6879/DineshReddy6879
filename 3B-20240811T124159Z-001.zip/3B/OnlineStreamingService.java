public class OnlineStreamingService {
    public void playStream() {
        System.out.println("Playing online stream");
    }

    public void stopStream() {
        System.out.println("Stopping online stream");
    }
}
