public interface EnrollmentManager {
    void enrollStudentInCourse(Student student, Course course);
}
