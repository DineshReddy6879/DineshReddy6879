
public interface PaymentFactory {
    PaymentMethod createPaymentMethod();
}

