
public interface PaymentMethod {
    String processPayment();
}

