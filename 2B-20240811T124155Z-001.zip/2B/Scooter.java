
public class Scooter implements Vehicle {
    @Override
    public String getType() {
        return "Scooter";
    }
}
