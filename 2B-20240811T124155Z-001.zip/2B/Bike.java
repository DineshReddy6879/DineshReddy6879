
public class Bike implements Vehicle {
    @Override
    public String getType() {
        return "Bike";
    }
}

